export interface kundeDto {

  profilePhoto?: FormData;
  userName?: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  dateOfBirth?: Date;
  password?: string;
  dtype : 'Kunde' ;

}
