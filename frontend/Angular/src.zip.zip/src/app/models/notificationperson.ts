export interface person {

  id?: number;
  userName?: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  Rating?: number;
  totalRides?: number;
}
