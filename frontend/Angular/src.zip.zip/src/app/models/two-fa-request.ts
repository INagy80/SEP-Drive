export interface TwoFaRequest {
  code?: string;
  userName?: string;
  password?: string;
}
