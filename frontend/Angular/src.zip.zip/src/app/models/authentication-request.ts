export interface AuthenticationRequest {
  userName?: string;
  password?: string;
}
